# Changelog - TO-ThermalLib

## [1.0.0] – 2025-06-21
### Added
- Estructura de repositorio
- Archivos base y documentación
